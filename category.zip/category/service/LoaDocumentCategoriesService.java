package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.service;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentCategoriesResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Service
public class LoaDocumentCategoriesService {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.service.LoaDocumentCategoriesService.class);

  private final RestTemplate categoryRestTemplate;

  @Value("${document.categories.api.endpoint}")
  private String documentCategoriesAPIEndpoint;

  public LoaDocumentCategoriesService(
      @Qualifier("documentCategoriesRestTemplate") RestTemplate categoryRestTemplate) {
    this.categoryRestTemplate = categoryRestTemplate;
  }

  @Cacheable(cacheManager = "simpleCacheManager", cacheNames = "loaDocumentCategories")
  public LoaDocumentCategoriesResponse getDocumentCategories(String opaqueBearerToken)
      throws com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException, com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException {
    LOGGER.info(" Enter DocumentCategoriesService.getDocumentCategories()");
    LoaDocumentCategoriesResponse loaDocumentCategoriesResponse;
    ResponseEntity<LoaDocumentCategoriesResponse> documentCategoriesResponseResponseEntity;
    try {
      URI documentCategoryURI = URI.create(documentCategoriesAPIEndpoint);
      MultiValueMap<String, String> documentCategoryHeaderMap = new LinkedMultiValueMap<>();
      documentCategoryHeaderMap.add("Authorization", opaqueBearerToken);
      HttpEntity<MultiValueMap<String, String>> documentCategoryHttpEntity =
          new HttpEntity<>(documentCategoryHeaderMap);
      RequestEntity loaDocumentCategoryRequestEntity =
          new RequestEntity(documentCategoryHttpEntity, HttpMethod.GET, documentCategoryURI);
      documentCategoriesResponseResponseEntity =
          categoryRestTemplate.exchange(
              loaDocumentCategoryRequestEntity, LoaDocumentCategoriesResponse.class);
      loaDocumentCategoriesResponse = documentCategoriesResponseResponseEntity.getBody();
      LOGGER.info(
          "Document Categories API {} returned a response with status code {}",
          documentCategoriesAPIEndpoint,
          documentCategoriesResponseResponseEntity.getStatusCode());
    } catch (HttpClientErrorException httpClientErrorException) {
      LOGGER.error(
          "Document Categories API {} threw a HttpClientErrorException with the http status code "
              + "{} and a body {}",
          documentCategoriesAPIEndpoint,
          httpClientErrorException.getStatusCode(),
          httpClientErrorException.getResponseBodyAsString());
      throw new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException(
          HttpStatus.valueOf(httpClientErrorException.getStatusCode().value()),
          httpClientErrorException.getResponseBodyAsString());
    } catch (HttpServerErrorException httpServerErrorException) {
      LOGGER.error(
          "Document Categories API {} threw a HttpServerErrorException with the http status code "
              + "{} and a body {}",
          documentCategoriesAPIEndpoint,
          httpServerErrorException.getStatusCode(),
          httpServerErrorException.getResponseBodyAsString());
      throw new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException(
          HttpStatus.valueOf(httpServerErrorException.getStatusCode().value()),
          httpServerErrorException.getResponseBodyAsString());
    }
    LOGGER.info("Exit DocumentCategoriesService.getDocumentCategories()");
    return loaDocumentCategoriesResponse;
  }
}