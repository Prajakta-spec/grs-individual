package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentsNotFoundException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidWbUserIdException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Positive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaArchiveDocumentsController {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller.LoaArchiveDocumentsController.class);

  private final RequestTracker requestTracker;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.archive.LoaArchiveMetadataService loaArchiveMetadataService;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository;

  public LoaArchiveDocumentsController(
      RequestTracker requestTracker,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.archive.LoaArchiveMetadataService loaArchiveMetadataService,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository) {
    this.requestTracker = requestTracker;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.loaArchiveMetadataService = loaArchiveMetadataService;
    this.loaMetadataService = loaMetadataService;
    this.loaArchiveUniqueDocumentIdRepository = loaArchiveUniqueDocumentIdRepository;
  }

  @DeleteMapping(
      path =
          Constants.LOA_ID_DYNAMIC_PATH_PARAMETER
              + "/documents/"
              + Constants.UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER)
  @Operation(
      summary = "Delete loa document by uniqueDocId",
      description = "Delete a loa document by loaId and uniqueDocId",
      method = "DELETE",
      tags = {"Loa Archive Document Content"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Loa Archive Document",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteResponse> deleteDocumentContentByUniqueDocId(
      @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @Positive(message = Constants.LOA_ID_GREATER_THAN_ZERO_MSG)
          @Max(value = Integer.MAX_VALUE, message = Constants.LOA_ID_NOT_VALID_INTEGER_MSG)
          Integer loaId,
      @PathVariable(value = Constants.UNIQUE_DOC_ID_PATH_PARAMETER) String uniqueDocId,
      @Parameter(name = Constants.WB_USER_ID_PARAMETER, example = "2053")
          @Positive(message = Constants.WB_USER_ID_PATCH_GREATER_THAN_ZERO_MSG)
          @RequestHeader(value = Constants.WB_USER_ID_PARAMETER, required = false)
          Integer wbUserId)
      throws DocumentsNotFoundException, InvalidWbUserIdException {
    String trackingId = requestTracker.getTrackingId();
    LOGGER.info(
        "{} - Enter LoaArchiveDocumentsController.deleteDocumentContentByUniqueDocId()"
            + " - loaId: {} and uniqueDocId: {}",
        trackingId,
        loaId,
        uniqueDocId);

    HttpStatus httpStatus = HttpStatus.OK;
    Optional<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> loaMetadataOptional =
        loaUniqueDocumentIdRepository.findById(uniqueDocId);
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteResponse loaDocumentDeleteResponse =
        new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteResponse();
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteSuccessResponseData loaDocumentDeleteSuccessResponseData;
    if (loaMetadataOptional.isPresent()) {
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata = loaMetadataOptional.get();
      if (loaId.equals(loaMetadata.getLoaId())) {
        loaDocumentDeleteSuccessResponseData = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteSuccessResponseData();
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentArchiveSuccessResponse loaDocumentArchiveSuccessResponse =
            new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentArchiveSuccessResponse();
        String verifiedWbUserId = null;
        if (wbUserId == null) {
          verifiedWbUserId = loaMetadataService.returnDefaultWbUserIdIfWbUserIdNull();
        } else if (loaMetadataService.isValidWbUserId(wbUserId.toString())) {
          verifiedWbUserId = wbUserId.toString();
        }
        if (verifiedWbUserId != null) {
          loaArchiveUniqueDocumentIdRepository.save(
              loaArchiveMetadataService.createLoaArchiveMetadata(
                      loaMetadata, Integer.valueOf(verifiedWbUserId)));

          LOGGER.info(
              "{} - Saving document in loa archive table trackingId: and loaId: {}",
              trackingId,
              loaId);
          loaUniqueDocumentIdRepository.delete(loaMetadata);
          LOGGER.info(
              "{} - deleting document {} from loa metadata table trackingId: and loaId {}",
              loaMetadata.getDocumentName(),
              trackingId,
              loaId);
          loaDocumentArchiveSuccessResponse.setMessage(
              loaMetadata.getDocumentName()
                  + " document of loaId:"
                  + loaMetadata.getLoaId()
                  + " deleted successfully");
        }
        loaDocumentDeleteResponse.setTrackingId(trackingId);
        loaDocumentDeleteResponse.setData(loaDocumentDeleteSuccessResponseData);
        loaDocumentDeleteSuccessResponseData.setDocumentArchive(
                loaDocumentArchiveSuccessResponse);
      } else {
        LOGGER.error(
            "{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
            trackingId,
            uniqueDocId,
            loaId);
        throw new DocumentsNotFoundException(
            HttpStatus.NOT_FOUND,
            "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
      }
    } else {
      LOGGER.error(
          "{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
          trackingId,
          uniqueDocId,
          loaId);
      throw new DocumentsNotFoundException(
          HttpStatus.NOT_FOUND,
          "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
    }

    LOGGER.info(
        "{} - Exit LoaArchiveDocumentsController.deleteDocumentContentByUniqueDocId()",
        trackingId);
    return new ResponseEntity<>(loaDocumentDeleteResponse, httpStatus);
  }
}