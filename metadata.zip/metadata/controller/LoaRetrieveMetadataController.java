package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;


import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.UniqueDocIdMetadataResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.UniqueDocIdMetadataSuccessResponseData;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentsNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaRetrieveMetadataController {

  private static final Logger LOGGER =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller.LoaRetrieveMetadataController.class);

  private static final String AND_LOA_ID = "and loaId:";

  private final RequestTracker requestTracker;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaIdReceivedDateRepository loaIdReceivedDateRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaIdArchiveRepository loaIdArchiveRepository;

  public LoaRetrieveMetadataController(
      RequestTracker requestTracker,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaIdReceivedDateRepository loaIdReceivedDateRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaIdArchiveRepository loaIdArchiveRepository) {
    this.requestTracker = requestTracker;
    this.loaIdReceivedDateRepository = loaIdReceivedDateRepository;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.loaArchiveUniqueDocumentIdRepository = loaArchiveUniqueDocumentIdRepository;
    this.loaIdArchiveRepository = loaIdArchiveRepository;
  }

  @GetMapping(path = Constants.LOA_ID_DYNAMIC_PATH_PARAMETER + "/document-metadata")
  @Operation(
      summary = "Retrieve all document metadata for a given loa",
      description = "Retrieve all document metadata for a given loa",
      method = "GET",
      tags = {"Loa Document Metadata"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Loa document metadata",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataResponse.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataResponse> getAllDocumentMetadataByLoaId(
      @RequestParam(value = Constants.FILTER_QUERY_PARAMETER, required = false)
          @Pattern(
              regexp = Constants.REGEX_CATEGORY_SUBCATEGORY_FILTER_QUERY_PARAMETER,
              message = Constants.INVALID_FILTER_REGEX_MESSAGE)
          String filter,
      @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @NotNull(message = Constants.LOA_ID_REQUIRED_MSG)
          @Positive(message = Constants.LOA_ID_GREATER_THAN_ZERO_MSG)
          @Max(value = Integer.MAX_VALUE, message = Constants.LOA_ID_NOT_VALID_INTEGER_MSG)
          Integer loaId)
      throws DocumentsNotFoundException {
    String trackingId = requestTracker.getTrackingId();
    String idToFilter;
    List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> loaMetadataList = null;
    List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata> loaArchiveMetadataList = null;
    HttpStatus httpStatus = HttpStatus.OK;
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataResponse loaDocumentMetadataResponse =
        new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataResponse();
    LOGGER.info(
        "{} - Enter LoaMetadataController.getAllDocumentMetadataByLoaId()"
            + " - loaId: {} and filter: {}",
        trackingId,
        loaId,
        filter);
    loaDocumentMetadataResponse.setTrackingId(trackingId);

    if (filter != null) {
      if (filter.startsWith(Constants.CATEGORY_FILTER_PATTERN)) {
        idToFilter = filter.split(Constants.CATEGORY_FILTER_PATTERN)[1];
        LOGGER.info("{} - Filter by categoryId: {}", trackingId, idToFilter);
        loaMetadataList =
            loaIdReceivedDateRepository.findByLoaIdAndCategoryIds(
                loaId, prepareFilterList(idToFilter));
      } else if (filter.startsWith(Constants.SUB_CATEGORY_FILTER_PATTERN)) {
        idToFilter = filter.split(Constants.SUB_CATEGORY_FILTER_PATTERN)[1];
        LOGGER.info("{} - Filter by subCategoryId: {}", trackingId, idToFilter);
        loaMetadataList =
            loaIdReceivedDateRepository.findByLoaIdAndSubCategoryIds(
                loaId, prepareFilterList(idToFilter));
      } else if (filter.startsWith(Constants.ARCHIVE_FILTER_PATTERN)) {
        boolean archive;
        archive = Boolean.parseBoolean(filter.split(Constants.ARCHIVE_FILTER_PATTERN)[1]);
        if (archive) {
          LOGGER.info(
              "{} - Enter LoaMetadataController.getAllDocumentMetadataByLoaId()"
                  + " - loaId: {}",
              trackingId,
              loaId);
          loaArchiveMetadataList = loaIdArchiveRepository.findAllByLoaId(loaId);
        }
      }

    } else {
      LOGGER.info("{} - No Filter provided. Just get them all", trackingId);
      loaMetadataList =
          loaIdReceivedDateRepository.findAllByLoaIdOrderByReceivedDateDesc(loaId);
    }

    if (loaMetadataList != null && !loaMetadataList.isEmpty()) {
      loaDocumentMetadataResponse.setData(
          prepareLoaDocumentMetadataSuccessResponse(loaMetadataList));
    } else if (loaArchiveMetadataList != null && !loaArchiveMetadataList.isEmpty()) {
      loaDocumentMetadataResponse.setData(
          prepareLoaDocumentArchiveMetadataSuccessResponse(loaArchiveMetadataList));
    } else {
      throw new DocumentsNotFoundException(
          HttpStatus.NOT_FOUND,
          "No records found in loa metadata db for loaId: " + loaId);
    }

    LOGGER.info(
        "{} - Exit LoaMetadataController.getAllDocumentMetadataByLoaId()", trackingId);
    return new ResponseEntity<>(loaDocumentMetadataResponse, httpStatus);
  }

  @GetMapping(
      path =
          Constants.LOA_ID_DYNAMIC_PATH_PARAMETER
              + "/document-metadata/"
              + Constants.UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER)
  @Operation(
      summary = "Retrieve document metadata for a given loa by uniqueDocId",
      description = "Retrieve document metadata for a given loa by uniqueDocId",
      method = "GET",
      tags = {"Loa Document Metadata"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Loa document metadata",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = UniqueDocIdMetadataResponse.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<UniqueDocIdMetadataResponse> getDocumentMetadataByUniqueDocId(
      @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @NotNull(message = Constants.LOA_ID_REQUIRED_MSG)
          @Positive(message = Constants.LOA_ID_GREATER_THAN_ZERO_MSG)
          @Max(value = Integer.MAX_VALUE, message = Constants.LOA_ID_NOT_VALID_INTEGER_MSG)
          Integer loaId,
      @PathVariable(value = Constants.UNIQUE_DOC_ID_PATH_PARAMETER)
          @NotNull(message = Constants.UNIQUE_DOC_ID_REQUIRED_MSG)
          String uniqueDocId,
      @RequestParam(value = Constants.FILTER_QUERY_PARAMETER, required = false)
          @Pattern(
              regexp = Constants.REGEX_ARCHIVE_FILTER_QUERY_PARAMETER,
              message = Constants.INVALID_ARCHIVE_FILTER_REGEX_MESSAGE)
          String filter)
      throws DocumentsNotFoundException {
    String trackingId = requestTracker.getTrackingId();
    HttpStatus httpStatus = HttpStatus.OK;
    UniqueDocIdMetadataResponse uniqueDocIdMetadataResponse = new UniqueDocIdMetadataResponse();
    if (filter != null && filter.startsWith(Constants.ARCHIVE_FILTER_PATTERN)) {
      LOGGER.info(
          "{} - Enter LoaMetadataController.getDocumentMetadataByUniqueDocId()"
              + " - loaId: {} and uniqueDocId: {}",
          trackingId,
          loaId,
          uniqueDocId);
      uniqueDocIdMetadataResponse.setTrackingId(trackingId);
      Optional<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata> loaArchiveMetadataOptional =
          loaArchiveUniqueDocumentIdRepository.findById(uniqueDocId);
      if (loaArchiveMetadataOptional.isPresent()) {
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata loaArchiveMetadata = loaArchiveMetadataOptional.get();
        if (loaId.equals(loaArchiveMetadata.getLoaId())) {
          uniqueDocIdMetadataResponse.setData(
              prepareUniqueDocIdArchiveMetadataSuccessResponse(loaArchiveMetadata));
        } else {
          throw new DocumentsNotFoundException(
              HttpStatus.NOT_FOUND,
              "No records found in loa archive metadata db for uniqueDocId: "
                  + uniqueDocId
                  + AND_LOA_ID
                  + loaId);
        }
      }
      LOGGER.info(
          "{} - Exit LoaMetadataController.getDocumentMetadataByUniqueDocId()", trackingId);
      return new ResponseEntity<>(uniqueDocIdMetadataResponse, httpStatus);
    } else {
      LOGGER.info(
          "{} - Enter LoaMetadataController.getDocumentMetadataByUniqueDocId()"
              + " - loaId: {} and uniqueDocId: {}",
          trackingId,
          loaId,
          uniqueDocId);
      uniqueDocIdMetadataResponse.setTrackingId(trackingId);
      Optional<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> loaMetadataOptional =
          loaUniqueDocumentIdRepository.findById(uniqueDocId);
      if (loaMetadataOptional.isPresent()) {
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata = loaMetadataOptional.get();
        if (loaId.equals(loaMetadata.getLoaId())) {
          uniqueDocIdMetadataResponse.setData(
              prepareUniqueDocIdMetadataSuccessResponse(loaMetadata));
        } else {
          throw new DocumentsNotFoundException(
              HttpStatus.NOT_FOUND,
              "No records found in loa metadata db for uniqueDocId: "
                  + uniqueDocId
                  + AND_LOA_ID
                  + loaId);
        }
      } else {
        throw new DocumentsNotFoundException(
            HttpStatus.NOT_FOUND,
            "No records found in loa metadata db for uniqueDocId: "
                + uniqueDocId
                + " and loaId: "
                + loaId);
      }
      LOGGER.info(
          "{} - Exit LoaMetadataController.getDocumentMetadataByUniqueDocId()", trackingId);
      return new ResponseEntity<>(uniqueDocIdMetadataResponse, httpStatus);
    }
  }

  private static List<Integer> prepareFilterList(String idToFilter) {
    return Stream.of(idToFilter.split(",")).map(Integer::parseInt).collect(Collectors.toList());
  }

  private static com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataSuccessResponseData
      prepareLoaDocumentMetadataSuccessResponse(List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> loaMetadataList) {
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataSuccessResponseData loaDocumentMetadataSuccessResponseData =
        new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataSuccessResponseData();
    loaDocumentMetadataSuccessResponseData.setLoaMetadata(loaMetadataList);
    return loaDocumentMetadataSuccessResponseData;
  }

  private static com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataSuccessResponseData
      prepareLoaDocumentArchiveMetadataSuccessResponse(
          List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata> loaArchiveMetadataList) {
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataSuccessResponseData loaDocumentMetadataSuccessResponseData =
        new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.LoaDocumentMetadataSuccessResponseData();
    loaDocumentMetadataSuccessResponseData.setLoaArchiveMetadata(
        loaArchiveMetadataList);
    return loaDocumentMetadataSuccessResponseData;
  }

  private static UniqueDocIdMetadataSuccessResponseData prepareUniqueDocIdMetadataSuccessResponse(
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata) {
    UniqueDocIdMetadataSuccessResponseData uniqueDocIdMetadataSuccessResponseData =
        new UniqueDocIdMetadataSuccessResponseData();
    uniqueDocIdMetadataSuccessResponseData.setLoaMetadata(loaMetadata);
    return uniqueDocIdMetadataSuccessResponseData;
  }

  private static UniqueDocIdMetadataSuccessResponseData
      prepareUniqueDocIdArchiveMetadataSuccessResponse(
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata loaArchiveMetadata) {
    UniqueDocIdMetadataSuccessResponseData uniqueDocIdMetadataSuccessResponseData =
        new UniqueDocIdMetadataSuccessResponseData();
    uniqueDocIdMetadataSuccessResponseData.setLoaArchiveMetadata(loaArchiveMetadata);
    return uniqueDocIdMetadataSuccessResponseData;
  }
}