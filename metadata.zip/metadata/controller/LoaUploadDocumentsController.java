package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.entity.WbCountry;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.repository.CountriesRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.EnvoyStoreResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.EnvoyStoreTransResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.*;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.EnvoyStoreService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Objects;
import java.util.Optional;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaUploadDocumentsController {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller.LoaUploadDocumentsController.class);

  private final RequestTracker requestTracker;

  private final EnvoyStoreService envoyStoreService;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  private final CountriesRepository countriesRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService;

  public LoaUploadDocumentsController(
      RequestTracker requestTracker,
      EnvoyStoreService envoyStoreService,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService,
      CountriesRepository countriesRepository) {
    this.requestTracker = requestTracker;
    this.envoyStoreService = envoyStoreService;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.loaMetadataService = loaMetadataService;
    this.countriesRepository = countriesRepository;
  }

  @PostMapping(
      path = Constants.LOA_ID_DYNAMIC_PATH_PARAMETER + "/documents",
      consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  @Operation(
      summary = "Upload an loa document",
      description = "Upload document for a given loa by id",
      method = "POST",
      tags = {"Loa Document Content"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "uniqueDocId - used for future retrieval",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse> uploadDocumentsForAnLoaById(
      @Parameter(name = Constants.LOA_MULTIPART_FILE_PARAMETER, required = true)
          @RequestParam(value = Constants.LOA_MULTIPART_FILE_PARAMETER)
          MultipartFile file,
      @Parameter(name = Constants.CATEGORY_ID_PARAMETER, example = "1", required = true)
          @RequestPart(value = Constants.CATEGORY_ID_PARAMETER)
          String categoryId,
      @Parameter(name = Constants.SUB_CATEGORY_ID_PARAMETER, example = "3", required = true)
          @RequestPart(value = Constants.SUB_CATEGORY_ID_PARAMETER)
          String subCategoryId,
      @Parameter(name = Constants.WB_USER_ID_PARAMETER, example = "2053")
          @RequestPart(value = Constants.WB_USER_ID_PARAMETER, required = false)
          String wbUserId,
      @Parameter(name = Constants.RECEIVED_DATE_PARAMETER, example = "2020-04-06", required = true)
          @RequestPart(value = Constants.RECEIVED_DATE_PARAMETER)
          @Pattern(
              regexp = Constants.REGEX_RECEIVED_DATE_PARAMETER,
              message = Constants.INVALID_RECEIVED_DATE_REGEX_MESSAGE)
          String receivedDate,
      @Parameter(name = Constants.PAYMENT_DATE_PARAMETER, example = "2020-04-06", required = false)
          @RequestPart(value = Constants.PAYMENT_DATE_PARAMETER, required = false)
          @Pattern(
              regexp = Constants.REGEX_RECEIVED_DATE_PARAMETER,
              message = Constants.INVALID_PAYMENT_DATE_REGEX_MESSAGE)
          String paymentDate,
      @Parameter(name = Constants.NOTES_PARAMETER, example = "Notes goes here")
          @RequestPart(value = Constants.NOTES_PARAMETER, required = false)
          String notes,
      @Parameter(name = Constants.CHECK_EFT_NUM_PARAMETER, example = "Check Eft Num goes here")
          @RequestPart(value = Constants.CHECK_EFT_NUM_PARAMETER, required = false)
          String checkEftNum,
      @Parameter(
              name = Constants.NPPI_PARAMETER,
              schema = @Schema(allowableValues = {"true", "false"}))
          @RequestPart(value = Constants.NPPI_PARAMETER, required = false)
          String nppi,
      @Parameter(
              name = Constants.REISSUE_PARAMETER,
              schema = @Schema(allowableValues = {"true", "false"}))
          @RequestPart(value = Constants.REISSUE_PARAMETER, required = false)
          String reissue,
      @Parameter(
              name = Constants.DOCUMENT_RESIDENCY_PARAMETER,
              example = "USA",
              description =
                  "ISO alpha3 country code - https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3")
          @RequestPart(value = Constants.DOCUMENT_RESIDENCY_PARAMETER, required = false)
          String documentResidency,
      @Parameter(name = Constants.LOA_ID_PATH_PARAMETER, example = "147853025", required = true)
          @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @Positive(message = Constants.LOA_ID_GREATER_THAN_ZERO_MSG)
          @Max(value = Integer.MAX_VALUE, message = Constants.LOA_ID_NOT_VALID_INTEGER_MSG)
          Integer loaId)
      throws JSONException,
          EnvoyClientException,
          EnvoyServerException,
          InvalidDocumentException,
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException,
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException,
          InvalidCategorySubCategoryException,
          InvalidIsoAlpha3CountryCodeException,
          InvalidWbCountryCodeException,
          InvalidWbUserIdException {
    String trackingId = requestTracker.getTrackingId();
    LOGGER.info(
        "{} - Enter LoaUploadDocumentsController.uploadDocumentsForAnLoaById", trackingId);
    if (file.isEmpty()) {
      LOGGER.error(
          "{} - InvalidDocumentException: Empty document {}",
          trackingId,
          file.getOriginalFilename());
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST, "Document " + file.getOriginalFilename() + " is empty");
    }
    if (file.getOriginalFilename() != null
        && loaMetadataService.hasNoExtension(file.getOriginalFilename())) {
      LOGGER.error("{} - InvalidDocumentException: Document has no extension", trackingId);
      throw new InvalidDocumentException(HttpStatus.BAD_REQUEST, "Document has no extension");
    }
    if (file.getOriginalFilename() == null
        || loaMetadataService.isInvalidDocumentName(file.getOriginalFilename())) {
      LOGGER.error(
          "{} - InvalidDocumentException: Document name {} is not valid",
          trackingId,
          file.getOriginalFilename());
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST, "Document name " + file.getOriginalFilename() + " is not valid");
    }

    if (isInvalidIntegerRequestPart(categoryId)) {
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          Constants.CATEGORY_ID_PARAMETER + Constants.INTEGER_GREATER_THAN_ZERO_ERROR_MSG);
    }

    if (isInvalidIntegerRequestPart(subCategoryId)) {
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          Constants.SUB_CATEGORY_ID_PARAMETER + Constants.INTEGER_GREATER_THAN_ZERO_ERROR_MSG);
    }

    if (subCategoryId != null
        && !Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_11.toString().equals(subCategoryId)
        && (paymentDate != null || checkEftNum != null || reissue != null)) {
      LOGGER.error("{} - Invalid Subcategory and attribute combination", trackingId);
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST, "the given attribute and subcategoryId Combination is not valid");
    }

    String verifiedWbUserId = null;
    if (wbUserId == null) {
      verifiedWbUserId = loaMetadataService.returnDefaultWbUserIdIfWbUserIdNull();
    } else if (loaMetadataService.isValidWbUserId(wbUserId)) {
      verifiedWbUserId = wbUserId;
    }

    if (nppi != null && isInvalidBooleanRequestPart(nppi)) {
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          Constants.NPPI_PARAMETER + " is a Boolean an should be true or false");
    }

    if (reissue != null && isInvalidBooleanRequestPart(reissue)) {
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          Constants.REISSUE_PARAMETER + " is a Boolean an should be true or false");
    }

    if (documentResidency == null) {
      LOGGER.info(
          "{} - {} is null. Setting to default value: {}",
          trackingId,
          Constants.DOCUMENT_RESIDENCY_PARAMETER,
          Constants.DEFAULT_DOCUMENT_RESIDENCY_COUNTRY_CODE);
      documentResidency = Constants.DEFAULT_DOCUMENT_RESIDENCY_COUNTRY_CODE;
    } else {
      if (!documentResidency.matches(Constants.ISO_ALPHA3_COUNTRY_CODE_REGEX)) {
        LOGGER.error(
            "{} - InvalidCategorySubCategoryException: {}: {} is not a valid ISO 3166-1 alpha-3 country code",
            trackingId,
            Constants.DOCUMENT_RESIDENCY_PARAMETER,
            documentResidency);
        throw new InvalidIsoAlpha3CountryCodeException(
            HttpStatus.BAD_REQUEST,
            Constants.DOCUMENT_RESIDENCY_PARAMETER
                + " "
                + documentResidency
                + " is not a valid ISO 3166-1 alpha-3 country code");
      } else if (!isValidWbCountryCode(documentResidency)) {
        LOGGER.error(
            "{} - InvalidWbCountryCodeException: {}: {} is not present in redis countries cache",
            trackingId,
            Constants.DOCUMENT_RESIDENCY_PARAMETER,
            documentResidency);
        throw new InvalidWbCountryCodeException(
            HttpStatus.BAD_REQUEST,
            Constants.DOCUMENT_RESIDENCY_PARAMETER
                + " "
                + documentResidency
                + " is not a valid country code in WB");
      }
    }

    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse loaDocumentStoreResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse();
    loaDocumentStoreResponse.setTrackingId(requestTracker.getTrackingId());
    if (!loaMetadataService.isValidCategorySubCategoryCombination(
        Integer.valueOf(categoryId),
        Integer.valueOf(Objects.requireNonNull(subCategoryId)),
        requestTracker.getOpaqueBearerToken())) {
      LOGGER.error(
          "{} - InvalidCategorySubCategoryException: Invalid Category and Sub Category combination",
          trackingId);
      throw new InvalidCategorySubCategoryException(
          HttpStatus.BAD_REQUEST, "Invalid Category and Sub Category combination");
    }

    Optional<String> optionalFileExtension = getDocumentExtension(file.getOriginalFilename());
    if (optionalFileExtension.isPresent()) {
      String documentExtension = optionalFileExtension.get();
      EnvoyStoreResponse envoyStoreResponse;

        envoyStoreResponse =
            envoyStoreService.uploadLoaDocuments(
                file, loaId, documentResidency, requestTracker.getTrackingId());

      if (envoyStoreResponse != null
          && envoyStoreResponse.getEnvoyStoreSuccessResponse() != null
          && envoyStoreResponse.getEnvoyStoreSuccessResponse().getEnvoyStoreTransResponse() != null
          && envoyStoreResponse
                  .getEnvoyStoreSuccessResponse()
                  .getEnvoyStoreTransResponse()
                  .getUniqueDocId()
              != null) {
        String uniqueDocId =
            envoyStoreResponse
                .getEnvoyStoreSuccessResponse()
                .getEnvoyStoreTransResponse()
                .getUniqueDocId();
        Boolean nppiBoolean = null;
        Boolean reissueBoolean = null;
        if (nppi != null) {
          nppiBoolean = Boolean.valueOf(nppi);
        }
        if (reissue != null) {
          reissueBoolean = Boolean.valueOf(reissue);
        }
        loaUniqueDocumentIdRepository.save(
            loaMetadataService.createLoaMetadata(
                uniqueDocId,
                loaId,
                Integer.valueOf(categoryId),
                Integer.valueOf(subCategoryId),
                Integer.valueOf(Objects.requireNonNull(verifiedWbUserId)),
                Integer.valueOf(verifiedWbUserId),
                receivedDate,
                paymentDate,
                file.getOriginalFilename(),
                documentExtension,
                (double) file.getSize(),
                notes,
                checkEftNum,
                nppiBoolean,
                reissueBoolean));
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreSuccessResponseData loaDocumentStoreSuccessResponseData =
            new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreSuccessResponseData();
        EnvoyStoreTransResponse envoyStoreTransResponse = new EnvoyStoreTransResponse();
        envoyStoreTransResponse.setUniqueDocId(uniqueDocId);
        loaDocumentStoreSuccessResponseData.setDocumentStore(envoyStoreTransResponse);
        loaDocumentStoreResponse.setData(loaDocumentStoreSuccessResponseData);
        LOGGER.info(
            "{} - Exit LoaUploadDocumentsController.uploadDocumentsForAnLoaById",
            trackingId);
        return new ResponseEntity<>(loaDocumentStoreResponse, HttpStatus.CREATED);
      } else {
        LOGGER.error(
            "{} - EnvoyServerException: Unexpected Error. Envoy did not return a uniqueDocId."
                + " Envoy may be down. Please retry later",
            trackingId);
        throw new EnvoyServerException(
            HttpStatus.INTERNAL_SERVER_ERROR,
            "Unexpected Error. Envoy did not return a uniqueDocId. Envoy may be down. Please retry later");
      }
    } else {
      LOGGER.error(
          "{} - InvalidDocumentException: Unsupported Document: Document LoaMultiPartFile"
              + "..getOriginalFilename() does not have an extension",
          trackingId);
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          "Unsupported Document: Document "
              + file.getOriginalFilename()
              + " does not have an extension");
    }
  }

  private static Optional<String> getDocumentExtension(String documentName) {
    return Optional.ofNullable(documentName)
        .filter(f -> f.contains("."))
        .map(f -> f.substring(documentName.lastIndexOf('.') + 1));
  }

  private static boolean isInvalidIntegerRequestPart(String partParameter) {
    int integerRequestPart = Integer.parseInt(partParameter);
    boolean isInvalidInteger = true;
    if (integerRequestPart > 0) {
      isInvalidInteger = false;
    }
    return isInvalidInteger;
  }

  private static boolean isInvalidBooleanRequestPart(String partParameter) {
    boolean isInvalidBoolean = true;
    if ("true".equalsIgnoreCase(partParameter) || "false".equalsIgnoreCase(partParameter)) {
      isInvalidBoolean = false;
    }
    return isInvalidBoolean;
  }

  private boolean isValidWbCountryCode(String wbCountryCode) {
    Optional<WbCountry> optionalWbCountry = countriesRepository.findByCode(wbCountryCode);
    return optionalWbCountry.isPresent();
  }
}