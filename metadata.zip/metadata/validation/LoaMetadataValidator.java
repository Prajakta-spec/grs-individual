package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.validation;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.repository.WbUsersRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentMetadataAlreadyExistException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidCategorySubCategoryException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidDocumentException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidWbUserIdException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Slf4j
@Component
public class LoaMetadataValidator {
  public static final String[] INVALID_FILE_NAME_CHARACTERS = {
    "\\", "/", ":", "*", "\"", "<", ">", "|"
  };

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService;

  private final WbUsersRepository wbUsersRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  public LoaMetadataValidator(
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService,
      WbUsersRepository wbUsersRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository) {
    this.loaMetadataService = loaMetadataService;
    this.wbUsersRepository = wbUsersRepository;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
  }

  public void validate(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaStoreMetadata loaStoreMetadata, String trackingId)
      throws InvalidDocumentException,
          InvalidCategorySubCategoryException,
          InvalidWbUserIdException,
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException,
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException,
          DocumentMetadataAlreadyExistException {

    // Validate that filename contains a dot(.), i.e. has file extension
    if (hasNoExtension(loaStoreMetadata.getDocumentName())) {
      log.info("{} - InvalidDocumentException: Document has no extension", trackingId);
      throw new InvalidDocumentException(HttpStatus.BAD_REQUEST, "Document has no extension");
    }

    // Validate doc name doesn't contain invalid characters
    if (isInvalidDocumentName(loaStoreMetadata.getDocumentName())) {
      log.info(
          "{} - InvalidDocumentException: Document name {} is not valid",
          trackingId,
          loaStoreMetadata.getDocumentName());
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          "Document name " + loaStoreMetadata.getDocumentName() + " is not valid");
    }

    // Validate category/sub-category combo
    if (!loaMetadataService.isValidCategorySubCategoryCombination(
        loaStoreMetadata.getCategoryId(), loaStoreMetadata.getSubCategoryId())) {
      log.info(
          "{} - InvalidCategorySubCategoryException: Invalid Category and Sub Category combination",
          trackingId);
      throw new InvalidCategorySubCategoryException(
          HttpStatus.BAD_REQUEST, "Invalid Category and Sub Category combination");
    }

    Integer subCategoryId;

    // Validate paymentDate/checkEftNum/reissues applies when SubCategoryId is 11
    if (loaStoreMetadata.getSubCategoryId() != null) {
      subCategoryId = loaStoreMetadata.getSubCategoryId();
      if (!Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_11.equals(subCategoryId)
          && (loaStoreMetadata.getPaymentDate() != null
              || loaStoreMetadata.getCheckEftNum() != null
              || loaStoreMetadata.getReissue() != null)) {
        log.error("{} - Invalid Subcategory and attribute combination", trackingId);
        throw new InvalidDocumentException(
            HttpStatus.BAD_REQUEST,
            "paymentDate or checkEftNum or reissues metadata applies only when subcategoryId is 11");
      }
    }

    // Validate WB user id is valid
    if (loaStoreMetadata.getCreatedById() != null
        && wbUsersRepository.findById(loaStoreMetadata.getCreatedById()).isEmpty()) {
      log.info(
          "{} - InvalidWbUserIdException: {}: {} is not present in redis wb users cache",
          trackingId,
          Constants.WB_USER_ID_PARAMETER,
          loaStoreMetadata.getCreatedById());
      throw new InvalidWbUserIdException(
          HttpStatus.BAD_REQUEST,
          Constants.WB_USER_ID_PARAMETER
              + " "
              + loaStoreMetadata.getCreatedById()
              + " is not a valid user id in WB");
    }

    // Validate that doc id does not already exist (is unique)
    if (loaUniqueDocumentIdRepository
        .findById(loaStoreMetadata.getUniqueDocId())
        .isPresent()) {
      log.info(
          "{} - DocumentMetadataAlreadyExistException: document already exists with the same uniqueDocId",
          trackingId);
      throw new DocumentMetadataAlreadyExistException(
          HttpStatus.BAD_REQUEST,
          "document already exists with the same uniqueDocId: "
              + loaStoreMetadata.getUniqueDocId());
    }
  }

  private boolean hasNoExtension(String documentName) {
    documentName = documentName.trim();
    int lastDotIndex = documentName.lastIndexOf('.');
    return lastDotIndex < 0 || lastDotIndex == documentName.length() - 1;
  }

  private boolean isInvalidDocumentName(String documentName) {
    return Arrays.stream(INVALID_FILE_NAME_CHARACTERS).parallel().anyMatch(documentName::contains);
  }
}