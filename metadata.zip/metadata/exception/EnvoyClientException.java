package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class EnvoyClientException extends Exception {

  private final HttpStatus httpStatusCode;

  public EnvoyClientException(HttpStatus httpStatusCode, String message) {
    super(message);
    this.httpStatusCode = httpStatusCode;
  }
}