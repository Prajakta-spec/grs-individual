package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class InvalidIsoAlpha3CountryCodeException extends Exception {

  private final HttpStatus httpStatusCode;

  public InvalidIsoAlpha3CountryCodeException(HttpStatus httpStatusCode, String message) {
    super(message);
    this.httpStatusCode = httpStatusCode;
  }
}