package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class DocumentsNotFoundException extends Exception {

  private final HttpStatus httpStatusCode;

  public DocumentsNotFoundException(HttpStatus httpStatusCode, String message) {
    super(message);
    this.httpStatusCode = httpStatusCode;
  }
}