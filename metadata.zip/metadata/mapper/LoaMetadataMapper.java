package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.mapper;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaStoreMetadata;
import org.mapstruct.*;

import java.util.Date;

@Mapper(componentModel = "spring")
public interface LoaMetadataMapper {

  @Mapping(
      source = "documentName",
      target = "documentExtension",
      qualifiedByName = "documentExtension")
      LoaMetadata loaStoreMetadataToLoaMetadata(LoaStoreMetadata loaStoreMetadata, @Context Integer loaId);
  @AfterMapping
  default void afterMapping(
          @MappingTarget com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata, @Context Integer loaId) {
    loaMetadata.setLoaId(loaId);
    loaMetadata.setCreatedAt(new Date());
    loaMetadata.setUpdatedAt(new Date());
  }

  @Named("documentExtension")
  default String extractDocumentExtension(String documentName) {
    return documentName.substring(documentName.lastIndexOf('.') + 1).trim();
  }
}