package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@DynamoDBTable(tableName = Constants.OBLIGEE_METADATA_DYNAMODB_TABLE)
public class LoaMetadata implements Serializable {

  @Serial private static final long serialVersionUID = 1L;

  @Id
  @DynamoDBHashKey(attributeName = "unique_doc_id")
  private String uniqueDocId;

  @DynamoDBIndexHashKey(
      globalSecondaryIndexNames = {
        "idx_global_obligee_id_order_received_date",
        "idx_global_category_id_and_obligee_id",
        "idx_global_sub_category_id_and_obligee_id",
        "idx_global_created_by_id_and_obligee_id",
        "idx_global_updated_by_id_and_obligee_id"
      },
      attributeName = "obligee_id")
  private Integer loaId;

  @DynamoDBIndexRangeKey(
      globalSecondaryIndexName = "idx_global_category_id_and_obligee_id",
      attributeName = "category_id")
  private Integer categoryId;

  @DynamoDBIndexRangeKey(
      globalSecondaryIndexName = "idx_global_sub_category_id_and_obligee_id",
      attributeName = "sub_category_id")
  private Integer subCategoryId;

  @DynamoDBIndexRangeKey(
      globalSecondaryIndexName = "idx_global_created_by_id_and_obligee_id",
      attributeName = "created_by_id")
  private Integer createdById;

  @DynamoDBIndexRangeKey(
      globalSecondaryIndexName = "idx_global_updated_by_id_and_obligee_id",
      attributeName = "updated_by_id")
  private Integer updatedById;

  @DynamoDBIndexRangeKey(
      globalSecondaryIndexName = "idx_global_obligee_id_order_received_date",
      attributeName = "received_date")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private String receivedDate;

  @DynamoDBAttribute(attributeName = "payment_date")
  @JsonFormat(pattern = "yyyy-MM-dd")
  private String paymentDate;

  @DynamoDBAttribute(attributeName = "name")
  private String documentName;

  @DynamoDBAttribute(attributeName = "extension")
  private String documentExtension;

  @DynamoDBAttribute(attributeName = "size")
  private Double documentSizeInBytes;

  @DynamoDBAttribute(attributeName = "notes")
  private String notes;

  @DynamoDBAttribute(attributeName = "check_eft_num")
  private String checkEftNum;

  @DynamoDBAttribute(attributeName = "nppi")
  private Boolean nppi;

  @DynamoDBAttribute(attributeName = "reissue")
  private Boolean reissue;

  @DynamoDBAttribute(attributeName = "created_at")
  private Date createdAt;

  @DynamoDBAttribute(attributeName = "updated_at")
  private Date updatedAt;
}