package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.update;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LoaPatchMetadata {

  @Positive(message = Constants.CATEGORY_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer categoryId;

  @Positive(message = Constants.SUB_CATEGORY_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer subCategoryId;

  @Positive(message = Constants.WB_USER_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer wbUserId;

  @Pattern(
      regexp = Constants.REGEX_RECEIVED_DATE_PARAMETER,
      message = Constants.INVALID_RECEIVED_DATE_PATCH_MESSAGE)
  private String receivedDate;

  @Pattern(
      regexp = Constants.REGEX_RECEIVED_DATE_PARAMETER,
      message = Constants.INVALID_PAYMENT_DATE_PATCH_MESSAGE)
  private String paymentDate;

  private String documentName;

  private String notes;

  private String checkEftNum;

  private Boolean nppi;

  private Boolean reissue;
}