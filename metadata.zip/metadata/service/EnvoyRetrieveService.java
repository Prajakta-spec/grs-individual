package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyClientException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyServerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class EnvoyRetrieveService {

  private static final Logger LOGGER = LoggerFactory.getLogger(EnvoyRetrieveService.class);

  private final RestTemplate envoyRestTemplate;

  @Value("${envoy.retrieve.content.api.endpoint}")
  private String envoyRetrieveEndpoint;

  public EnvoyRetrieveService(@Qualifier("envoyRestTemplate") RestTemplate envoyRestTemplate) {
    this.envoyRestTemplate = envoyRestTemplate;
  }

  public Resource retrieveLoaDocuments(String trackingId, String uniqueDocId)
      throws EnvoyClientException, EnvoyServerException {
    LOGGER.info("{} - Enter EnvoyRetrieveService.retrieveLoaDocuments()", trackingId);
    ResponseEntity<Resource> envoyRetrieveContentResponseEntity;
    String retrieveContentAPI = envoyRetrieveEndpoint + uniqueDocId + "/native";
    try {
      envoyRetrieveContentResponseEntity =
          envoyRestTemplate.exchange(retrieveContentAPI, HttpMethod.GET, null, Resource.class);
    } catch (HttpClientErrorException httpClientErrorException) {
      LOGGER.error(
          "{} - Envoy Retrieve Content API {} threw a HttpClientErrorException with the http status code: {} "
              + "and a body {}",
          trackingId,
          retrieveContentAPI,
          httpClientErrorException.getStatusCode(),
          httpClientErrorException.getResponseBodyAsByteArray());
      throw new EnvoyClientException(
          HttpStatus.valueOf(httpClientErrorException.getStatusCode().value()),
          httpClientErrorException.getResponseBodyAsString());
    } catch (HttpServerErrorException httpServerErrorException) {
      LOGGER.error(
          "{} - Envoy Retrieve Content API {}threw a HttpServerErrorException with the http status code: {} "
              + "and a body {}",
          trackingId,
          retrieveContentAPI,
          httpServerErrorException.getStatusCode(),
          httpServerErrorException.getResponseBodyAsString());
      throw new EnvoyServerException(
          HttpStatus.valueOf(httpServerErrorException.getStatusCode().value()),
          httpServerErrorException.getResponseBodyAsString());
    }
    LOGGER.info("{} - Exit EnvoyRetrieveService.retrieveLoaDocuments()", trackingId);
    return envoyRetrieveContentResponseEntity.getBody();
  }
}
