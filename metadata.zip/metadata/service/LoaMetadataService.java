package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service;


import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentCategoriesResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentCategory;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentSubCategory;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.entity.WbUser;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.repository.WbUsersRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidWbUserIdException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class LoaMetadataService {
  private static final String[] INVALID_FILE_NAME_CHARACTERS = {
    "\\", "/", ":", "*", "\"", "<", ">", "|"
  };

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.service.LoaDocumentCategoriesService loaDocumentCategoriesService;

  private final WbUsersRepository wbUsersRepository;

  private final RequestTracker requestTracker;

  @Value("${document.management.default-wb-user}")
  private String documentManagementDefaultWbUser;

  public LoaMetadataService(
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.service.LoaDocumentCategoriesService loaDocumentCategoriesService,
      WbUsersRepository wbUsersRepository,
      RequestTracker requestTracker) {
    this.loaDocumentCategoriesService = loaDocumentCategoriesService;
    this.wbUsersRepository = wbUsersRepository;
    this.requestTracker = requestTracker;
  }

  public com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata createLoaMetadata(
      String uniqueDocId,
      Integer loaId,
      Integer categoryId,
      Integer subCategoryId,
      Integer createdById,
      Integer updatedById,
      String receivedDate,
      String paymentDate,
      String documentName,
      String documentExtension,
      Double fileSizeInBytes,
      String notes,
      String checkEftNum,
      Boolean nppi,
      Boolean reissue) {
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata();
    loaMetadata.setUniqueDocId(uniqueDocId);
    loaMetadata.setLoaId(loaId);
    loaMetadata.setCategoryId(categoryId);
    loaMetadata.setSubCategoryId(subCategoryId);
    loaMetadata.setCreatedById(createdById);
    loaMetadata.setUpdatedById(updatedById);
    loaMetadata.setReceivedDate(receivedDate);
    loaMetadata.setDocumentName(documentName);
    loaMetadata.setDocumentExtension(documentExtension);
    loaMetadata.setDocumentSizeInBytes(fileSizeInBytes);
    if (paymentDate != null) {
      loaMetadata.setPaymentDate(paymentDate);
    }
    if (notes != null) {
      loaMetadata.setNotes(notes);
    }
    if (checkEftNum != null) {
      loaMetadata.setCheckEftNum(checkEftNum);
    }
    if (nppi != null) {
      loaMetadata.setNppi(nppi);
    }
    if (reissue != null) {
      loaMetadata.setReissue(reissue);
    }
    loaMetadata.setCreatedAt(new Date());
    loaMetadata.setUpdatedAt(new Date());
    return loaMetadata;
  }

  public boolean isValidCategorySubCategoryCombination(
      Integer categoryId, Integer subCategoryId, String opaqueBearerToken)
      throws com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException, com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException {
    boolean isValidCategorySubCategoryCombination = false;
    LoaDocumentCategoriesResponse loaDocumentCategoriesResponse =
        loaDocumentCategoriesService.getDocumentCategories(opaqueBearerToken);
    if (loaDocumentCategoriesResponse != null
        && loaDocumentCategoriesResponse.getData() != null
        && loaDocumentCategoriesResponse.getData().getDocumentCategories() != null) {
      List<LoaDocumentCategory> loaDocumentCategoryList =
          loaDocumentCategoriesResponse.getData().getDocumentCategories();
      for (LoaDocumentCategory loaDocumentCategory : loaDocumentCategoryList) {
        if (loaDocumentCategory.getDocumentCategoryId().equals(categoryId)) {
          List<LoaDocumentSubCategory> loaDocumentSubCategoryList =
              loaDocumentCategory.getDocumentSubCategories();
          for (LoaDocumentSubCategory loaDocumentSubCategory :
              loaDocumentSubCategoryList) {
            if (loaDocumentSubCategory.getDocumentSubCategoryId().equals(subCategoryId)) {
              isValidCategorySubCategoryCombination = true;
              break;
            }
          }
        }
      }
    }
    return isValidCategorySubCategoryCombination;
  }

  public boolean isValidCategorySubCategoryCombination(Integer categoryId, Integer subCategoryId)
      throws com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException, com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException {
    return this.isValidCategorySubCategoryCombination(
        categoryId, subCategoryId, requestTracker.getOpaqueBearerToken());
  }

  public boolean isInvalidDocumentName(String documentName) {
    return Arrays.stream(INVALID_FILE_NAME_CHARACTERS).parallel().anyMatch(documentName::contains);
  }

  public boolean hasNoExtension(String documentName) {
    return documentName.lastIndexOf('.') < 0;
  }

  public String returnDefaultWbUserIdIfWbUserIdNull() throws InvalidWbUserIdException {
    String trackingId = requestTracker.getTrackingId();
    String wbUserId;
    if (getDefaultDocMgmtWbUserId(documentManagementDefaultWbUser) != null) {
      wbUserId = getDefaultDocMgmtWbUserId(documentManagementDefaultWbUser);
      log.info(
          "{} - {} is null. Setting to documentManagementDefaultServiceUserId value",
          trackingId,
          Constants.WB_USER_ID_PARAMETER);
    } else {
      log.error("{} - Doc mgmt default user does not exist in cached Admin data", trackingId);
      throw new InvalidWbUserIdException(
          HttpStatus.INTERNAL_SERVER_ERROR,
          "  Doc mgmt default user does not exist in cached Admin data");
    }
    return wbUserId;
  }

  public boolean isValidWbUserId(String wbUserId) throws InvalidWbUserIdException {
    String trackingId = requestTracker.getTrackingId();
    if (isInvalidIntegerRequestPart(wbUserId)) {
      throw new InvalidWbUserIdException(
          HttpStatus.BAD_REQUEST,
          Constants.WB_USER_ID_PARAMETER + Constants.INTEGER_GREATER_THAN_ZERO_ERROR_MSG);
    } else if (!isValidWbUserId(Integer.valueOf(wbUserId))) {
      log.error(
          "{} - InvalidWbUserIdException: {}: {} is not present in redis wb users cache",
          trackingId,
          Constants.WB_USER_ID_PARAMETER,
          wbUserId);
      throw new InvalidWbUserIdException(
          HttpStatus.BAD_REQUEST,
          Constants.WB_USER_ID_PARAMETER + " " + wbUserId + " is not a valid user id in WB");
    } else {
      return true;
    }
  }

  private boolean isValidWbUserId(Integer wbUserId) {
    Optional<WbUser> optionalWbUser = wbUsersRepository.findById(wbUserId);
    return optionalWbUser.isPresent();
  }

  private String getDefaultDocMgmtWbUserId(String nNumber) {
    String wbUserId = null;
    Optional<WbUser> optionalWbUser = wbUsersRepository.findBynnumber(nNumber);
    if (optionalWbUser.isPresent()) {
      Integer defaultWbUser = optionalWbUser.get().getId();
      if (defaultWbUser != null) {
        wbUserId = defaultWbUser.toString();
      }
    }
    return wbUserId;
  }

  private static boolean isInvalidIntegerRequestPart(String partParameter) {
    int integerRequestPart = Integer.parseInt(partParameter);
    boolean isInvalidInteger = true;
    if (integerRequestPart > 0) {
      isInvalidInteger = false;
    }
    return isInvalidInteger;
  }
}