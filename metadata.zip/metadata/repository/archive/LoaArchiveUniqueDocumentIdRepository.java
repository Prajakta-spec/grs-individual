package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface LoaArchiveUniqueDocumentIdRepository
    extends PagingAndSortingRepository<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata, String>,
        CrudRepository<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata, String> {}