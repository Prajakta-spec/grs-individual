package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive;

import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface LoaIdArchiveRepository
    extends PagingAndSortingRepository<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata, com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaId> {

  List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata> findAllByLoaId(Integer loaId);
}