package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface LoaUniqueDocumentIdRepository extends PagingAndSortingRepository<LoaMetadata, String>,
        CrudRepository<LoaMetadata, String> {}