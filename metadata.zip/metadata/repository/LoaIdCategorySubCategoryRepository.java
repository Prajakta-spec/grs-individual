package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository;

import java.util.List;

public interface LoaIdCategorySubCategoryRepository {

  List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> findByLoaIdAndCategoryIds(Integer loaId, List<Integer> categoryIds);

  List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> findByLoaIdAndSubCategoryIds(
      Integer loaId, List<Integer> subCategoryIds);
}