package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaIdReceivedDate;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface LoaIdReceivedDateRepository
    extends PagingAndSortingRepository<LoaMetadata, LoaIdReceivedDate>,
        LoaIdCategorySubCategoryRepository {

  List<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> findAllByLoaIdOrderByReceivedDateDesc(Integer loaId);
}