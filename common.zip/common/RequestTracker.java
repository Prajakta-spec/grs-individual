package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

@Getter
@Setter
@RequestScope
@Component
public class RequestTracker {

  private String trackingId;

  private String opaqueBearerToken;
}