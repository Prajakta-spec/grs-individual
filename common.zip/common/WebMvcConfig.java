package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@Profile({
  Constants.DEVELOPMENT_ENVIRONMENT,
  Constants.TEST_ENVIRONMENT,
  Constants.STAGING_ENVIRONMENT,
  Constants.PERFORMANCE_ENVIRONMENT,
  Constants.INTEGRATION_ENVIRONMENT,
  Constants.PRODUCTION_ENVIRONMENT
})
public class WebMvcConfig implements WebMvcConfigurer {

  private final IncomingRequestInterceptor incomingRequestInterceptor;

  public WebMvcConfig(IncomingRequestInterceptor incomingRequestInterceptor) {
    this.incomingRequestInterceptor = incomingRequestInterceptor;
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(incomingRequestInterceptor).addPathPatterns("/api/v1/**");
  }

  @Override
  public void addCorsMappings(CorsRegistry registry) {
    registry
        .addMapping("/api/v1/**")
        .allowedMethods(
            HttpMethod.GET.name(),
            HttpMethod.POST.name(),
            HttpMethod.PATCH.name(),
            HttpMethod.DELETE.name())
        .allowedHeaders("*")
        .allowedOrigins(
            Constants.DEV_AGENCY_DOC_MGMT_UI,
            Constants.QA_AGENCY_DOC_MGMT_UI,
            Constants.UAT_AGENCY_DOC_MGMT_UI,
            Constants.PERF_AGENCY_DOC_MGMT_UI,
            Constants.INT_AGENCY_DOC_MGMT_UI,
            Constants.PROD_AGENCY_DOC_MGMT_UI);
  }
}