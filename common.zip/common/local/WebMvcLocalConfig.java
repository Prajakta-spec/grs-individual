package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.local;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.IncomingRequestInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.LOCAL_DOCKER_ENVIRONMENT,
  Constants.INTEGRATION_TEST_ENVIRONMENT
})
public class WebMvcLocalConfig implements WebMvcConfigurer {

  private final IncomingRequestInterceptor incomingRequestInterceptor;

  public WebMvcLocalConfig(IncomingRequestInterceptor incomingRequestInterceptor) {
    this.incomingRequestInterceptor = incomingRequestInterceptor;
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(incomingRequestInterceptor).addPathPatterns("/api/v1/**");
  }

  @Override
  public void addCorsMappings(CorsRegistry registry) {
    registry
        .addMapping("/api/v1/**")
        .allowedMethods(
            HttpMethod.OPTIONS.name(),
            HttpMethod.GET.name(),
            HttpMethod.POST.name(),
            HttpMethod.PATCH.name(),
            HttpMethod.DELETE.name())
        .allowedHeaders("*")
        .allowedOrigins(Constants.LOCAL_AGENCY_DOC_MGMT_UI, Constants.LOCAL_AGENCY_DOC_MGMT_UI_SSL);
  }
}