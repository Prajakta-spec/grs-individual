package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping.PingJwtAuthenticationConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.oauth2.server.resource.authentication.OpaqueTokenAuthenticationProvider;
import org.springframework.security.oauth2.server.resource.introspection.NimbusOpaqueTokenIntrospector;
import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@EnableWebSecurity
@EnableConfigurationProperties(IdpProperties.class)
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.DEVELOPMENT_ENVIRONMENT,
  Constants.TEST_ENVIRONMENT,
  Constants.STAGING_ENVIRONMENT,
  Constants.PERFORMANCE_ENVIRONMENT,
  Constants.INTEGRATION_ENVIRONMENT,
  Constants.PRODUCTION_ENVIRONMENT
})
@Configuration
public class BearerTokenSecurityConfig {
  private static final String API_V1 = "/api/v1/**";

  private static final String VIEW_AGENCY_AGENCY_SERVICES = "can_view_agency_agency_services";
  private static final String VIEW_AGENCY_CUSTOMER_ACCOUNTING =
      "can_view_agency_customer_accounting";
  private static final String VIEW_AGENCY_GENERAL_CORRESPONDENCE =
      "can_view_agency_general_correspondence";
  private static final String VIEW_AGENCY_AGENCY_STATEMENTS = "can_view_agency_agency_statements";
  private static final String VIEW_AGENCY_DB_COMMISSION_STATEMENTS =
      "can_view_agency_db_commission_statements";

  private static final String EDIT_AGENCY_AGENCY_SERVICES = "can_edit_agency_agency_services";
  private static final String EDIT_AGENCY_CUSTOMER_ACCOUNTING =
      "can_edit_agency_customer_accounting";
  private static final String EDIT_AGENCY_GENERAL_CORRESPONDENCE =
      "can_edit_agency_general_correspondence";
  private static final String EDIT_AGENCY_AGENCY_STATEMENTS = "can_edit_agency_agency_statements";
  private static final String EDIT_AGENCY_DB_COMMISSION_STATEMENTS =
      "can_edit_agency_db_commission_statements";

  @Value("${idp.resourceserver.opaquetoken.introspection-uri}")
  private String idpIntrospectionUri;

  @Value("${idp.resourceserver.opaquetoken.client-id}")
  private String idpClientId;

  @Value("${idp.resourceserver.opaquetoken.client-secret}")
  private String idpClientSecret;

  private final PingJwtAuthenticationConverter pingJwtAuthenticationConverter;

  private final JwtDecoder pingJwtDecoder;

  private final JwtDecoder auth0JwtDecoder;

  private final JwtAuthenticationConverter auth0JwtAuthenticationConverter;

  public BearerTokenSecurityConfig(
      PingJwtAuthenticationConverter pingJwtAuthenticationConverter,
      JwtDecoder pingJwtDecoder,
      JwtDecoder auth0JwtDecoder,
      JwtAuthenticationConverter auth0JwtAuthenticationConverter) {
    this.pingJwtAuthenticationConverter = pingJwtAuthenticationConverter;
    this.pingJwtDecoder = pingJwtDecoder;
    this.auth0JwtDecoder = auth0JwtDecoder;
    this.auth0JwtAuthenticationConverter = auth0JwtAuthenticationConverter;
  }

  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    JwtAuthenticationProvider auth0JwtAuthenticationProvider =
        new JwtAuthenticationProvider(auth0JwtDecoder);
    auth0JwtAuthenticationProvider.setJwtAuthenticationConverter(auth0JwtAuthenticationConverter);

    JwtAuthenticationProvider pingJwtAuthenticationProvider =
        new JwtAuthenticationProvider(pingJwtDecoder);
    pingJwtAuthenticationProvider.setJwtAuthenticationConverter(pingJwtAuthenticationConverter);

    OpaqueTokenAuthenticationProvider opaqueTokenAuthenticationProvider =
        new OpaqueTokenAuthenticationProvider(opaqueTokenIntrospector());

    http.cors(withDefaults())
        .authorizeHttpRequests(
            authorizeHttpRequests ->
                authorizeHttpRequests
                    .requestMatchers(HttpMethod.GET, API_V1)
                    .hasAnyAuthority(
                        Constants.PING_READ,
                        Constants.AUTH0_READ,
                        Constants.SCOPE_OPENID,
                        Constants.SCOPE_PROFILE,
                        Constants.SCOPE_EMAIL,
                        VIEW_AGENCY_AGENCY_SERVICES,
                        VIEW_AGENCY_CUSTOMER_ACCOUNTING,
                        VIEW_AGENCY_GENERAL_CORRESPONDENCE,
                        VIEW_AGENCY_AGENCY_STATEMENTS,
                        VIEW_AGENCY_DB_COMMISSION_STATEMENTS,
                        EDIT_AGENCY_AGENCY_SERVICES,
                        EDIT_AGENCY_CUSTOMER_ACCOUNTING,
                        EDIT_AGENCY_GENERAL_CORRESPONDENCE,
                        EDIT_AGENCY_AGENCY_STATEMENTS,
                        EDIT_AGENCY_DB_COMMISSION_STATEMENTS)
                    .requestMatchers(HttpMethod.PATCH, API_V1)
                    .hasAnyAuthority(
                        Constants.PING_WRITE,
                        Constants.AUTH0_WRITE,
                        Constants.SCOPE_OPENID,
                        Constants.SCOPE_PROFILE,
                        Constants.SCOPE_EMAIL,
                        EDIT_AGENCY_AGENCY_SERVICES,
                        EDIT_AGENCY_CUSTOMER_ACCOUNTING,
                        EDIT_AGENCY_GENERAL_CORRESPONDENCE,
                        EDIT_AGENCY_AGENCY_STATEMENTS,
                        EDIT_AGENCY_DB_COMMISSION_STATEMENTS)
                    .requestMatchers(HttpMethod.POST, API_V1)
                    .hasAnyAuthority(
                        Constants.PING_WRITE,
                        Constants.AUTH0_WRITE,
                        Constants.SCOPE_OPENID,
                        Constants.SCOPE_PROFILE,
                        Constants.SCOPE_EMAIL,
                        EDIT_AGENCY_AGENCY_SERVICES,
                        EDIT_AGENCY_CUSTOMER_ACCOUNTING,
                        EDIT_AGENCY_GENERAL_CORRESPONDENCE,
                        EDIT_AGENCY_AGENCY_STATEMENTS,
                        EDIT_AGENCY_DB_COMMISSION_STATEMENTS)
                    .requestMatchers(HttpMethod.DELETE, API_V1)
                    .hasAnyAuthority(
                        Constants.PING_DELETE,
                        Constants.AUTH0_DELETE,
                        Constants.SCOPE_OPENID,
                        Constants.SCOPE_PROFILE,
                        Constants.SCOPE_EMAIL,
                        EDIT_AGENCY_AGENCY_SERVICES,
                        EDIT_AGENCY_CUSTOMER_ACCOUNTING,
                        EDIT_AGENCY_GENERAL_CORRESPONDENCE,
                        EDIT_AGENCY_AGENCY_STATEMENTS,
                        EDIT_AGENCY_DB_COMMISSION_STATEMENTS)
                    .requestMatchers("/swagger-ui*/**")
                    .permitAll()
                    .requestMatchers("/api-docs/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/actuator/health")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/health/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/actuator/info")
                    .permitAll()
                    .anyRequest()
                    .authenticated())
        .oauth2ResourceServer(
            oauth2 ->
                oauth2.authenticationManagerResolver(
                    context ->
                        new ProviderManager(
                            auth0JwtAuthenticationProvider,
                            pingJwtAuthenticationProvider,
                            opaqueTokenAuthenticationProvider)));
    return http.build();
  }

  @Bean
  public WebSecurityCustomizer webSecurityCustomizer() {
    return (web) ->
        web.ignoring()
            .requestMatchers("/swagger-ui*/**")
            .requestMatchers("/api-docs/**")
            .requestMatchers("/actuator/health")
            .requestMatchers("/actuator/info")
            .requestMatchers("/health/**");
  }

  @Bean
  public OpaqueTokenIntrospector opaqueTokenIntrospector() {
    return new NimbusOpaqueTokenIntrospector(
        this.idpIntrospectionUri, this.idpClientId, this.idpClientSecret);
  }
}