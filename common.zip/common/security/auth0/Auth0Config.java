package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.auth0;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.IdpProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Slf4j
@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.DEVELOPMENT_ENVIRONMENT,
  Constants.TEST_ENVIRONMENT,
  Constants.STAGING_ENVIRONMENT,
  Constants.PERFORMANCE_ENVIRONMENT,
  Constants.INTEGRATION_ENVIRONMENT,
  Constants.PRODUCTION_ENVIRONMENT
})
public class Auth0Config {

  private final IdpProperties idpProperties;
  private final WebClient webClient;

  public Auth0Config(IdpProperties idpProperties, WebClient.Builder webClientBuilder) {
    this.idpProperties = idpProperties;
    this.webClient = webClientBuilder.filter(logRequest()).filter(logResponse()).build();
  }

  private static ExchangeFilterFunction logRequest() {
    return ExchangeFilterFunction.ofRequestProcessor(
        clientRequest -> {
          if (log.isTraceEnabled()) {
            log.trace("Request: {} {}", clientRequest.method(), clientRequest.url());
            clientRequest
                .headers()
                .forEach(
                    (name, values) -> values.forEach(value -> log.trace("{}={}", name, value)));
          }
          return Mono.just(clientRequest);
        });
  }

  private static ExchangeFilterFunction logResponse() {
    return ExchangeFilterFunction.ofResponseProcessor(
        clientResponse -> {
          if (log.isTraceEnabled()) {
            log.trace("Response status: {}", clientResponse.statusCode());
            clientResponse
                .headers()
                .asHttpHeaders()
                .forEach(
                    (name, values) -> values.forEach(value -> log.trace("{}={}", name, value)));
          }
          return Mono.just(clientResponse);
        });
  }

  @Bean
  public JwtDecoder auth0JwtDecoder() {
    return JwtDecoders.fromIssuerLocation(idpProperties.getAuth0().getIssuerUri());
  }

  @Bean
  public JwtAuthenticationConverter auth0JwtAuthenticationConverter() {
    Auth0GrantedAuthorityConverter auth0GrantedAuthorityConverter =
        new Auth0GrantedAuthorityConverter(
            idpProperties.getAuth0().getResourceServerName(),
            idpProperties.getAuth0().isPullAuthorization(),
            this.webClient);
    JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
    jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(auth0GrantedAuthorityConverter);
    return jwtAuthenticationConverter;
  }
}
