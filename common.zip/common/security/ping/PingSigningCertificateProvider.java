package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.IdpProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.io.IOException;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Slf4j
@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.DEVELOPMENT_ENVIRONMENT,
  Constants.TEST_ENVIRONMENT,
  Constants.STAGING_ENVIRONMENT,
  Constants.PERFORMANCE_ENVIRONMENT,
  Constants.INTEGRATION_ENVIRONMENT,
  Constants.PRODUCTION_ENVIRONMENT
})
public class PingSigningCertificateProvider {

  private X509Certificate cachedCertificate;

  private final IdpProperties idpProperties;

  private Instant lastCached;

  public PingSigningCertificateProvider(IdpProperties idpProperties) {
    this.idpProperties = idpProperties;
  }

  public X509Certificate apply() throws PingException {
    final URL jwkSigningCertURL = idpProperties.getPing().getSigningCertUri();

    final Duration signingCertificateCacheTime = Duration.of(1, ChronoUnit.HOURS);
    if (cachedCertificate == null
        || lastCached.plus(signingCertificateCacheTime).isBefore(Instant.now())) {
      try {
        log.info("Getting X509 Certificate to signing certificate from - {}", jwkSigningCertURL);
        final X509Certificate certificate =
            (X509Certificate)
                CertificateFactory.getInstance("X509")
                    .generateCertificate(jwkSigningCertURL.openStream());
        log.debug("Generated Certificate - {}", certificate);
        cachedCertificate = certificate;
        lastCached = Instant.now();
        log.info(
            "Caching Certificate. Cache Time - {}. Time until next refresh - {}",
            lastCached,
            lastCached.plus(signingCertificateCacheTime));
        return certificate;
      } catch (final CertificateException e) {
        log.error(
            "Certificate Exception Getting Signing Certificate from URL - {}",
            jwkSigningCertURL,
            e);
        throw new PingException("Issue getting the X509 certificate used to sign the JWTs", e);
      } catch (final IOException e) {
        log.error("IO Exception Getting Signing Certificate from URL - {}", jwkSigningCertURL, e);
        throw new PingException(
            "IO Exception when getting the X509 certificate used to sign the JWTs", e);
      }
    } else {
      final Instant timeUntilNextRefresh = lastCached.plus(signingCertificateCacheTime);
      final Instant currentTime = Instant.now();
      log.debug(
          "Returning cached certificate. Current Time - {}, Next Refresh - {}, Time Until Next Refresh - {} milliseconds",
          currentTime,
          timeUntilNextRefresh,
          timeUntilNextRefresh.minusMillis(currentTime.toEpochMilli()).toEpochMilli());
      return cachedCertificate;
    }
  }
}