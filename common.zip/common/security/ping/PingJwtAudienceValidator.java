package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.obligee.common.security.ping;

import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.Objects;
import java.util.Set;

public final class PingJwtAudienceValidator implements OAuth2TokenValidator<Jwt> {

  private final Set<String> expectedAudiences;

  public PingJwtAudienceValidator(Set<String> expectedAudiences) {
    this.expectedAudiences = expectedAudiences;
  }

  @Override
  public OAuth2TokenValidatorResult validate(final Jwt token) {
    final boolean acceptableAudiencesOnToken =
        token.getAudience().stream().filter(Objects::nonNull).anyMatch(expectedAudiences::contains);
    if (acceptableAudiencesOnToken) {
      return OAuth2TokenValidatorResult.success();
    } else {
      return OAuth2TokenValidatorResult.failure(
          new OAuth2Error(
              "invalid_request",
              "This aud claim does not contain the configured audience. Expected "
                  + expectedAudiences
                  + " got "
                  + token.getAudience().toString(),
              "https://tools.ietf.org/html/rfc6750#section-5.3"));
    }
  }
}