package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common;

import io.micrometer.common.lang.NonNullApi;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.UUID;

@Component
@NonNullApi
public class IncomingRequestInterceptor implements HandlerInterceptor {

  private final RequestTracker requestTracker;

  public IncomingRequestInterceptor(RequestTracker requestTracker) {
    this.requestTracker = requestTracker;
  }

  @Override
  public boolean preHandle(
      HttpServletRequest request, HttpServletResponse response, Object handler) {
    requestTracker.setTrackingId(UUID.randomUUID().toString());
    requestTracker.setOpaqueBearerToken(request.getHeader("Authorization"));
    return true;
  }
}