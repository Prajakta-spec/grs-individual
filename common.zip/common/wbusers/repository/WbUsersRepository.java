package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.repository;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.entity.WbUser;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface WbUsersRepository extends CrudRepository<WbUser, Integer> {

  Optional<WbUser> findBynnumber(String nnumber);
}